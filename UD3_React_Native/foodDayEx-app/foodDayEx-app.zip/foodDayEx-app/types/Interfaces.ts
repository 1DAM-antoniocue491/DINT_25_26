export interface IFood{
    name: string,
    kcal: number,
    icon: string
}