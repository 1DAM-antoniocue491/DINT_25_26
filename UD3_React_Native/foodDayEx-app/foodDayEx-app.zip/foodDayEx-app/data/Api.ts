import { foodList } from "./Data";

export function getData(){
    return foodList;
}