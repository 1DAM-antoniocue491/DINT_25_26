import React from "react"
import Header from "./Header"
import ImagenLibro from "../assets/libroImagen.jpg"
import { getArticles } from "../data/api"

export default function Articles() {
    const [articles] = React.useState(getArticles())

    return (
        <>
        <Header />
        
        <div className="flex flex-col items-center pb-20">
            <h1 className="text-3xl">Artículos</h1>

            <div className="grid grid-cols-1 gap-4 lg:grid-cols-2 md:grid-cols-1">
                {
                    articles.map((article) => (
                        <div className="rounded-2xl shadow-2xl mt-10">
                            <div className="relative overflow-hidden p-10 rounded-t-2xl">
                                <img className="absolute inset-0 w-full h-full object-cover z-0" src={ImagenLibro} alt="Imagen" />
                                <img className="relative z-10 w-40 rounded-2xl" src={article.imagen} alt="Imagen" />
                            </div>
                            <div className="p-4">
                                <p className="text-2xl">{article.titulo}</p>
                                <p>{article.descripcion}</p>
                            </div>
                        </div>
                    ))
                }
            </div>
        </div>
        </>
    )
}