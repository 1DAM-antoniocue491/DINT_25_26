export interface IArticles {
    id: number;
    titulo: string;
    imagen: string;
    descripcion: string;
}