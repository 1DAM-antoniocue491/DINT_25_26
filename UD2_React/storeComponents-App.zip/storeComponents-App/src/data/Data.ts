import type { ICatery, IProduct } from "../types/Interfaces";

export const categories: ICatery[] = [
  {
    id: 1,
    title: "Ordenadores",
    url: "https://png.pngtree.com/png-vector/20240811/ourmid/pngtree-full-tower-led-cabinet-gaming-atx-industrial-aluminum-metal-alloy-server-png-image_13446693.png"
  },
  {
    id: 2,
    title: "Portátiles",
    url: "https://png.pngtree.com/png-vector/20250522/ourmid/pngtree-modern-laptop-computer-with-screen-open-technology-digital-device-png-image_16345445.png"
  },
  {
    id: 3,
    title: "Smartphones",
    url: "https://png.pngtree.com/png-vector/20250307/ourmid/pngtree-latest-model-mobile-phone-png-image_15739741.png"
  },
  {
    id: 4,
    title: "Monitores",
    url: "https://asset.msi.com/resize/image/global/product/product_1675826253f57958b3253172ddb04ccbfb8aee2c91.png62405b38c58fe0f07fcef2367d8a9ba1/600.png"
  },
  {
    id: 5,
    title: "Consolas",
    url: "https://png.pngtree.com/png-clipart/20241001/original/pngtree-top-quality-play-station-console-isolated-on-transparent-background-png-image_16140505.png"
  },
  {
    id: 6,
    title: "Televisores",
    url: "https://png.pngtree.com/png-vector/20240821/ourmid/pngtree-smart-android-tv-png-image_13218874.png"
  },
  {
    id: 7,
    title: "Sonido",
    url: "https://png.pngtree.com/png-vector/20250321/ourmid/pngtree-wireless-headphone-png-image_15830312.png"
  },
  {
    id: 8,
    title: "Hogar",
    url: "https://png.pngtree.com/png-vector/20240128/ourmid/pngtree-3d-illustration-air-fryer-in-kitchen-set-png-image_11507053.png"
  },
];

export const products: IProduct[] = [
  // 1) ORDENADORES
  { id: 1, name: "PcCom Work Intel Core i5-12400 / 16GB / 500GB SSD", brand: "PcCom", category: 1, image: "https://img.pccomponentes.com/articles/1078/10789627/1272-pccom-intel-core-i5-12400-16gb-500gb-ssd-comprar.jpg", isTrending: true, discountPercent: 9, originalPrice: 519, stars: 4, reviews: 1049},
  { id: 2, name: "MSI MAG Infinite S3 13th Gen i5 / RTX 4060", brand: "MSI", category: 1, image: "https://img.pccomponentes.com/articles/1083/10838597/1474-msi-mag-infinite-s3-14nud5-1807es-intel-core-i5-14400f-16gb-1tb-ssd-rtx-4060-ti-opiniones.jpg", isTrending: true, discountPercent: 12, originalPrice: 1399, stars: 5, reviews: 862},
  { id: 3, name: "HP Pavilion Gaming TG01 Ryzen 5 / 16GB / 1TB SSD", brand: "HP", category: 1, image: "https://m.media-amazon.com/images/I/71Sy5I0aZ-L.jpg", isTrending: false, discountPercent: 8, originalPrice: 899, stars: 4, reviews: 534},
  { id: 4, name: "Lenovo Legion T5 i7-12700F / RTX 3060", brand: "Lenovo", category: 1, image: "https://m.media-amazon.com/images/I/71LAgOJDLTL._AC_UF350,350_QL80_.jpg", isTrending: true, discountPercent: 15, originalPrice: 1249, stars: 5, reviews: 675},
  { id: 5, name: "ASUS ROG Strix G15 Gaming Desktop", brand: "ASUS", category: 1, image: "https://dlcdnwebimgs.asus.com/gain/7118171A-7184-4F5E-9326-3AD0703BDC6C/w1000/h732", isTrending: false, discountPercent: 6, originalPrice: 1599, stars: 4, reviews: 281},
  { id: 6, name: "NZXT Player One i5 / 16GB / 1TB SSD", brand: "NZXT", category: 1, image: "https://checkout.nzxt.com/cdn/shop/files/Player-One-WW-04.11.25-HERO-BLACK-BADGE_1.png?crop=center&height=1200&v=1746141535&width=1200", isTrending: false, discountPercent: 10, originalPrice: 999, stars: 4, reviews: 392},
  { id: 7, name: "PcComponentes Gaming AMD Ryzen 7 / RX 7600", brand: "PcComponentes", category: 1, image: "https://thumb.pccomponentes.com/w-530-530/articles/1084/10842871/1830-pc-racing-amd-ryzen-7-8700g-16gb-1tb-ssd-rx-7600.jpg", isTrending: true, discountPercent: 20, originalPrice: 1349, stars: 5, reviews: 1102},
  { id: 8, name: "HP OMEN 40L i7 / 32GB / 1TB SSD", brand: "HP", category: 1, image: "https://img.pccomponentes.com/articles/1036/10364729/1370-hp-omen-40l-gt21-0049ns-intel-core-i7-12700k-32gb-1tb-ssd-1tb-rtx-3070-bf7fc7f6-45b2-4c4a-b9dd-8e94adb40401.jpg", isTrending: true, discountPercent: 25, originalPrice: 1999, stars: 5, reviews: 903},
  { id: 9, name: "MSI Pro DP21 Mini PC i5 / 16GB", brand: "MSI", category: 1, image: "https://m.media-amazon.com/images/I/71uSYOQ46wL.jpg", isTrending: false, discountPercent: 7, originalPrice: 749, stars: 3, reviews: 223},
  { id: 10, name: "Dell XPS Desktop i7 / 16GB / 512GB SSD", brand: "Dell", category: 1, image: "https://m.media-amazon.com/images/I/81rt17lGrmL._AC_UF894,1000_QL80_.jpg", isTrending: false, discountPercent: 5, originalPrice: 1099, stars: 4, reviews: 334},
  { id: 11, name: "ASUS ExpertCenter D7 SFF i5", brand: "ASUS", category: 1, image: "https://dlcdnwebimgs.asus.com/gain/9f96bee5-bde0-43c5-9632-b8ddf8d20961/", isTrending: false, discountPercent: 3, originalPrice: 829, stars: 3, reviews: 82},
  { id: 12, name: "PcCom Basic Office Intel i3 / 8GB / 500GB SSD", brand: "PcCom", category: 1, image: "https://thumb.pccomponentes.com/w-530-530/articles/1079/10795955/1960-pccom-work-intel-core-i3-12100-16gb-500gb-ssd-windows-11-home-caracteristicas.jpg", isTrending: false, discountPercent: 0, originalPrice: 499, stars: 3, reviews: 94},

  // 2) PORTÁTILES
  { id: 13, name: "Lenovo IdeaPad 3 15ALC6 Ryzen 5", brand: "Lenovo", category: 2, image: "https://dam.elcorteingles.es/producto/www-001054715252299-00.jpg?impolicy=Resize&width=1200&height=1200", isTrending: false, discountPercent: 10, originalPrice: 549, stars: 4, reviews: 482},
  { id: 14, name: "ASUS VivoBook 15 X1504VA", brand: "ASUS", category: 2, image: "https://img.pccomponentes.com/articles/1092/10928021/1563-asus-vivobook-15-x1504va-bq2858w-156-intel-core-5-120u-16gb-512gb-ssd-oled-180-azul-teclado-frances.jpg", isTrending: false, discountPercent: 8, originalPrice: 599, stars: 4, reviews: 365},
  { id: 15, name: "HP 15s-fq5000 Intel Core i5", brand: "HP", category: 2, image: "https://m.media-amazon.com/images/I/71zxrtcKf4L._AC_UF1000,1000_QL80_.jpg", isTrending: false, discountPercent: 5, originalPrice: 649, stars: 3, reviews: 192},
  { id: 16, name: "Acer Aspire 5 A515-58P", brand: "Acer", category: 2, image: "https://m.media-amazon.com/images/I/71KC2NI+E0L.jpg", isTrending: false, discountPercent: 12, originalPrice: 699, stars: 4, reviews: 265},
  { id: 17, name: "MSI Thin GF63 15.6\" i5 + RTX 2050", brand: "MSI", category: 2, image: "https://m.media-amazon.com/images/I/81GrrCZlpDL._AC_UF894,1000_QL80_.jpg", isTrending: true, discountPercent: 20, originalPrice: 899, stars: 5, reviews: 713},
  { id: 18, name: "ASUS TUF Gaming F15 FX507", brand: "ASUS", category: 2, image: "https://dlcdnwebimgs.asus.com/gain/3a36a12f-9a0d-488c-bef3-05431f041b96/", isTrending: true, discountPercent: 18, originalPrice: 1099, stars: 5, reviews: 612},
  { id: 19, name: "Lenovo LOQ 15IRH i5 + RTX 4050", brand: "Lenovo", category: 2, image: "https://thumb.pccomponentes.com/w-530-530/articles/1079/10791763/1404-lenovo-loq-15irh8-intel-core-i5-12450h-16gb-512gb-ssd-rtx-4050-156.jpg", isTrending: false, discountPercent: 10, originalPrice: 1149, stars: 4, reviews: 293},
  { id: 20, name: "HP Victus 16 Ryzen 7", brand: "HP", category: 2, image: "https://thumb.pccomponentes.com/w-530-530/articles/1057/10577497/1257-hp-victus-16-e0067ns-amd-ryzen-7-6800h-16gb-512gb-ssd-rtx-3050-161.jpg", isTrending: true, discountPercent: 25, originalPrice: 1249, stars: 5, reviews: 754},
  { id: 21, name: "Apple MacBook Air M2 13", brand: "Apple", category: 2, image: "https://store.storeimages.cdn-apple.com/1/as-images.apple.com/is/macbook-air-og-202503?wid=1200&hei=630&fmt=jpeg&qlt=90&.v=1739216814915", isTrending: true, discountPercent: 8, originalPrice: 1449, stars: 5, reviews: 1230},
  { id: 22, name: "Dell Inspiron 14 5420", brand: "Dell", category: 2, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQM1uoMxTk9v88ng-6T8BorPWvfqowelxlOFw&s", isTrending: false, discountPercent: 6, originalPrice: 999, stars: 4, reviews: 204},
  { id: 23, name: "Lenovo ThinkPad E14 Gen 5", brand: "Lenovo", category: 2, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ31JNwW9ndaEw5SYW9LMSkk2LsSFDgl7QcVg&s", isTrending: false, discountPercent: 5, originalPrice: 1099, stars: 4, reviews: 348},
  { id: 24, name: "ASUS ROG Zephyrus G14", brand: "ASUS", category: 2, image: "https://dlcdnwebimgs.asus.com/gain/BA146EC2-FF9D-4A8E-A91A-C9F864DE6BBB", isTrending: true, discountPercent: 15, originalPrice: 1899, stars: 5, reviews: 982},

  // 3) SMARTPHONES
  { id: 25, name: "Samsung Galaxy A55 5G 256GB", brand: "Samsung", category: 3, image: "https://fotosuraj.com/60498-large_default/samsung-galaxy-a55-5g-8gb-256gb.jpg", isTrending: true, discountPercent: 10, originalPrice: 499, stars: 5, reviews: 1552},
  { id: 26, name: "Xiaomi Redmi Note 13 Pro", brand: "Xiaomi", category: 3, image: "https://m.media-amazon.com/images/I/51BJw+RHx8L._AC_UF1000,1000_QL80_.jpg", isTrending: true, discountPercent: 12, originalPrice: 379, stars: 5, reviews: 2210},
  { id: 27, name: "iPhone 15 128GB", brand: "Apple", category: 3, image: "https://thumb.pccomponentes.com/w-530-530/articles/1077/10777737/1515-apple-iphone-15-128gb-negro-libre.jpg", isTrending: true, discountPercent: 5, originalPrice: 969, stars: 5, reviews: 642},
  { id: 28, name: "Samsung Galaxy S24", brand: "Samsung", category: 3, image: "https://m.media-amazon.com/images/I/51WGAx2x2nL._AC_UF1000,1000_QL80_.jpg", isTrending: true, discountPercent: 7, originalPrice: 1099, stars: 5, reviews: 843},
  { id: 29, name: "POCO X6 Pro 5G", brand: "POCO", category: 3, image: "https://cdn.idealo.com/folder/Product/203721/3/203721346/s11_produktbild_gross/xiaomi-poco-x6-pro.jpg", isTrending: false, discountPercent: 15, originalPrice: 449, stars: 4, reviews: 512},
  { id: 30, name: "OnePlus 12R", brand: "OnePlus", category: 3, image: "https://m.media-amazon.com/images/I/61VzJBDj0NL.jpg", isTrending: true, discountPercent: 20, originalPrice: 699, stars: 5, reviews: 934},
  { id: 31, name: "Google Pixel 8", brand: "Google", category: 3, image: "https://m.media-amazon.com/images/I/71HBgGfmUsL._AC_UF894,1000_QL80_.jpg", isTrending: false, discountPercent: 10, originalPrice: 799, stars: 5, reviews: 489},
  { id: 32, name: "Xiaomi 14T", brand: "Xiaomi", category: 3, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSTt72AIf80wB6PZ112q83ozq2SDJunZg18rw&s", isTrending: false, discountPercent: 12, originalPrice: 749, stars: 4, reviews: 238},
  { id: 33, name: "Realme 12 Pro+", brand: "Realme", category: 3, image: "https://static.fnac-static.com/multimedia/Images/ES/MC/8b/53/91/9524107/1507-1/tsp20250205131008/Realme-12-Pro-5G-Dual-SIM-12GB-512GB-6-67-Azul.jpg", isTrending: false, discountPercent: 8, originalPrice: 499, stars: 4, reviews: 185},
  { id: 34, name: "Motorola Moto G54 5G", brand: "Motorola", category: 3, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTQxFfdBdDPmqhH6pll4YQ_65INKn4i8B_J5w&s", isTrending: false, discountPercent: 5, originalPrice: 229, stars: 3, reviews: 157},
  { id: 35, name: "Samsung Galaxy A35", brand: "Samsung", category: 3, image: "https://owp.klarna.com/product/640x640/3222290725/Samsung-Galaxy-A35-5G-6GB-RAM-128GB-Awesome-Navy.jpg?ph=true", isTrending: false, discountPercent: 7, originalPrice: 319, stars: 4, reviews: 298},
  { id: 36, name: "iPhone 13 128GB", brand: "Apple", category: 3, image: "https://thumb.pccomponentes.com/w-530-530/articles/1019/10191365/1884-apple-iphone-13-128gb-verde-alpino-libre.jpg", isTrending: false, discountPercent: 10, originalPrice: 799, stars: 5, reviews: 1210},

  // 4) MONITORES
  { id: 37, name: "MSI G2722 27\" IPS 170Hz", brand: "MSI", category: 4, image: "https://ultimainformatica.com/2551273/msi-g2722-pantalla-para-pc-686-cm-27-1920-x-1080-pixeles-full-hd-led-negro.jpg", isTrending: false, discountPercent: 10, originalPrice: 189, stars: 4, reviews: 233},
  { id: 38, name: "LG 27GN800-B 27\" QHD 144Hz", brand: "LG", category: 4, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQYJFlGOzouePwnMLmgE8vFQDZyE96AOcATpA&s", isTrending: true, discountPercent: 12, originalPrice: 299, stars: 5, reviews: 512},
  { id: 39, name: "Samsung Odyssey G5 32\" Curved", brand: "Samsung", category: 4, image: "https://images.samsung.com/is/image/samsung/p6pim/es/ls32cg552euxen/gallery/es-odyssey-g5-g55c-526413-526413-ls32cg552euxen-thumb-543953046", isTrending: true, discountPercent: 15, originalPrice: 329, stars: 5, reviews: 721},
  { id: 40, name: "AOC 24G2SPAE/BK 24\" 165Hz", brand: "AOC", category: 4, image: "https://m.media-amazon.com/images/I/716IWf-oGcL._AC_UF894,1000_QL80_.jpg", isTrending: false, discountPercent: 8, originalPrice: 159, stars: 4, reviews: 285},
  { id: 41, name: "ASUS TUF Gaming VG27AQ 27\" QHD", brand: "ASUS", category: 4, image: "https://m.media-amazon.com/images/I/71ifg9fVjQL.jpg", isTrending: true, discountPercent: 18, originalPrice: 349, stars: 5, reviews: 804},
  { id: 42, name: "Philips 272E1GAEZ 27\" FHD", brand: "Philips", category: 4, image: "https://m.media-amazon.com/images/I/61ldB+otb6L.jpg", isTrending: false, discountPercent: 5, originalPrice: 189, stars: 4, reviews: 139},
  { id: 43, name: "Dell UltraSharp U2723QE 27\" 4K", brand: "Dell", category: 4, image: "https://m.media-amazon.com/images/I/61ijE-prqQL._AC_UF894,1000_QL80_.jpg", isTrending: true, discountPercent: 20, originalPrice: 649, stars: 5, reviews: 388},
  { id: 44, name: "LG 34WP65C-B 34\" Ultrawide", brand: "LG", category: 4, image: "https://cdn.idealo.com/folder/Product/201650/7/201650792/s11_produktbild_gross/lg-34wp65c-b.jpg", isTrending: false, discountPercent: 10, originalPrice: 399, stars: 4, reviews: 214},
  { id: 45, name: "Samsung Smart Monitor M7 32\"", brand: "Samsung", category: 4, image: "https://m.media-amazon.com/images/I/71seELVp6TL.jpg", isTrending: false, discountPercent: 7, originalPrice: 349, stars: 4, reviews: 172},
  { id: 46, name: "BenQ MOBIUZ EX2510S 24.5\"", brand: "BenQ", category: 4, image: "https://m.media-amazon.com/images/I/61Os4rhkYdL._AC_UF350,350_QL80_.jpg", isTrending: true, discountPercent: 15, originalPrice: 259, stars: 5, reviews: 395},
  { id: 47, name: "Gigabyte G27Q 27\" QHD", brand: "Gigabyte", category: 4, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQXPbVjNfFhsa2eNbUKKmG5HHY214JL1t0HPA&s", isTrending: false, discountPercent: 9, originalPrice: 299, stars: 4, reviews: 168},
  { id: 48, name: "HP X27qc 27\" QHD 165Hz", brand: "HP", category: 4, image: "https://m.media-amazon.com/images/I/71LDy4h7EfL.jpg", isTrending: false, discountPercent: 11, originalPrice: 279, stars: 4, reviews: 142},

  // 5) CONSOLAS
  { id: 49, name: "PlayStation 5 Slim 1TB", brand: "Sony", category: 5, image: "https://m.media-amazon.com/images/I/51NbBH89m1L._AC_UF894,1000_QL80_.jpg", isTrending: true, discountPercent: 10, originalPrice: 549, stars: 5, reviews: 2845},
  { id: 50, name: "Xbox Series X 1TB", brand: "Microsoft", category: 5, image: "https://thumb.pccomponentes.com/w-530-530/articles/32/323078/1684-microsoft-xbox-series-x-1tb.jpg", isTrending: true, discountPercent: 12, originalPrice: 529, stars: 5, reviews: 2534},
  { id: 51, name: "Nintendo Switch OLED", brand: "Nintendo", category: 5, image: "https://www.neobyte.es/91032-large_default/nintendo-switch-oled-blanca-consola-portatil.jpg", isTrending: true, discountPercent: 5, originalPrice: 349, stars: 5, reviews: 1864},
  { id: 52, name: "PlayStation 5 Digital Edition", brand: "Sony", category: 5, image: "https://m.media-amazon.com/images/I/51NbBH89m1L.jpg", isTrending: false, discountPercent: 15, originalPrice: 499, stars: 5, reviews: 1173},
  { id: 53, name: "Xbox Series S 512GB", brand: "Microsoft", category: 5, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSZJKLfDShxVwNub5g5z-rZx2S1RyMhniDozg&s", isTrending: false, discountPercent: 10, originalPrice: 289, stars: 4, reviews: 1045},
  { id: 54, name: "Nintendo Switch Lite", brand: "Nintendo", category: 5, image: "https://www.nintendo.com/eu/media/images/08_content_images/systems_5/nintendo_switch_3/nintendo_switch_lite_2/NSwitchLiteYellow.png", isTrending: false, discountPercent: 5, originalPrice: 199, stars: 4, reviews: 856},
  { id: 55, name: "PlayStation 5 + EA Sports FC", brand: "Sony", category: 5, image: "https://blog.es.playstation.com/uploads/sites/14/2043/09/028e0c586599c1ee2391671f6e3afb500749ad4a-scaled.jpg", isTrending: true, discountPercent: 20, originalPrice: 579, stars: 5, reviews: 2543},
  { id: 56, name: "Xbox Series X Forza Horizon Bundle", brand: "Microsoft", category: 5, image: "https://m.media-amazon.com/images/I/61p3jtMDMfL.jpg", isTrending: false, discountPercent: 15, originalPrice: 569, stars: 5, reviews: 1332},
  { id: 57, name: "Nintendo Switch OLED Zelda Edition", brand: "Nintendo", category: 5, image: "https://assets.mmsrg.com/isr/166325/c1/-/ASSET_MP_137543751?x=536&y=402&format=jpg&quality=80&sp=yes&strip=yes&trim&ex=536&ey=402&align=center&resizesource&unsharp=1.5x1+0.7+0.02&cox=0&coy=0&cdx=536&cdy=402", isTrending: true, discountPercent: 18, originalPrice: 379, stars: 5, reviews: 2217},
  { id: 58, name: "PlayStation 5 + Spider-Man 2", brand: "Sony", category: 5, image: "https://cdn.idealo.com/folder/Product/203349/0/203349057/s11_produktbild_gross/sony-playstation-5-ps5-marvel-s-spider-man-2.jpg", isTrending: true, discountPercent: 14, originalPrice: 589, stars: 5, reviews: 1920},
  { id: 59, name: "Xbox Series S Starter Bundle", brand: "Microsoft", category: 5, image: "https://media.game.es/COVERV2/3D_L/234/234953.png", isTrending: false, discountPercent: 7, originalPrice: 309, stars: 4, reviews: 764},
  { id: 60, name: "Steam Deck OLED 512GB", brand: "Valve", category: 5, image: "https://m.media-amazon.com/images/I/51q-NHeNaRL.jpg", isTrending: true, discountPercent: 10, originalPrice: 679, stars: 5, reviews: 1892},

  // 6) TELEVISORES
  { id: 61, name: "Samsung QLED Q60D 55\"", brand: "Samsung", category: 6, image: "https://m.media-amazon.com/images/I/81nUNvTZBTL._AC_UF894,1000_QL80_.jpg", isTrending: true, discountPercent: 12, originalPrice: 699, stars: 5, reviews: 944},
  { id: 62, name: "LG OLED C3 55\"", brand: "LG", category: 6, image: "https://m.media-amazon.com/images/I/61Xuk55HhuL._AC_UF1000,1000_QL80_.jpg", isTrending: true, discountPercent: 15, originalPrice: 1099, stars: 5, reviews: 1290},
  { id: 63, name: "Xiaomi TV A Pro 55\"", brand: "Xiaomi", category: 6, image: "https://assets.mmsrg.com/isr/166325/c1/-/ASSET_MMS_161038408?x=536&y=402&format=jpg&quality=80&sp=yes&strip=yes&trim&ex=536&ey=402&align=center&resizesource&unsharp=1.5x1+0.7+0.02&cox=0&coy=0&cdx=536&cdy=402", isTrending: false, discountPercent: 10, originalPrice: 449, stars: 4, reviews: 418},
  { id: 64, name: "Sony Bravia XR X90L 55\"", brand: "Sony", category: 6, image: "https://sony.scene7.com/is/image/sonyglobalsolutions/TVFY23_X90L_Primary-Image-1?$S7Product$&fmt=png-alpha", isTrending: true, discountPercent: 18, originalPrice: 1299, stars: 5, reviews: 886},
  { id: 65, name: "TCL QD-MiniLED C855 65\"", brand: "TCL", category: 6, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRly_UO690C7PQg7d-0slHZJxzvoF3AUyppfA&s", isTrending: false, discountPercent: 9, originalPrice: 899, stars: 4, reviews: 501},
  { id: 66, name: "Hisense U7KQ 55\"", brand: "Hisense", category: 6, image: "https://www.hisense.es/wp-content/uploads/2024/02/U7KQ.png", isTrending: false, discountPercent: 10, originalPrice: 599, stars: 4, reviews: 412},
  { id: 67, name: "Samsung Crystal UHD CU8000 50\"", brand: "Samsung", category: 6, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTdb1fuprnq9DlRgFL6WB1QI2PugkTFw9I-CQ&s", isTrending: false, discountPercent: 8, originalPrice: 499, stars: 4, reviews: 375},
  { id: 68, name: "LG NanoCell NANO77 55\"", brand: "LG", category: 6, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQCF1eUnarbzUm4GAIMCEom-wTzpvxdGau-2g&s", isTrending: false, discountPercent: 7, originalPrice: 529, stars: 4, reviews: 284},
  { id: 69, name: "Philips Ambilight PUS8818 58\"", brand: "Philips", category: 6, image: "https://thumb.pccomponentes.com/w-530-530/articles/1073/10735368/1223-philips-the-one-50pus8818-ambilight-50-led-ultrahd-4k-hdr10.jpg", isTrending: true, discountPercent: 15, originalPrice: 749, stars: 5, reviews: 721},
  { id: 70, name: "Toshiba QE5D 55\"", brand: "Toshiba", category: 6, image: "https://thumb.pccomponentes.com/w-530-530/articles/1088/10881345/1882-toshiba-qled-55qv3f63dg-55-4k-ultra-hd-dolby-vision-atmos-bluetooth-frameless.jpg", isTrending: false, discountPercent: 10, originalPrice: 499, stars: 4, reviews: 194},
  { id: 71, name: "Xiaomi TV Max 65\"", brand: "Xiaomi", category: 6, image: "https://www.powerplanetonline.com/cdnassets/xiaomi_tv_a_65_2025_01_l.jpg", isTrending: true, discountPercent: 20, originalPrice: 999, stars: 5, reviews: 639},
  { id: 72, name: "Sony Bravia XR A80L 65\" OLED", brand: "Sony", category: 6, image: "https://canarias.worten.es/i/fe600508ff2622e71b8df0c8aad4c8c1e30dc969", isTrending: true, discountPercent: 18, originalPrice: 1499, stars: 5, reviews: 1004},

  // 7) SONIDO
  { id: 73, name: "Sony WH-1000XM5", brand: "Sony", category: 7, image: "https://helpguide.sony.net/mdr/wh1000xm5/v1/es/contents/image/Top_image_WH-1000XM5.png", isTrending: true, discountPercent: 15, originalPrice: 399, stars: 5, reviews: 1934},
  { id: 74, name: "JBL Charge 5 Altavoz Bluetooth", brand: "JBL", category: 7, image: "https://m.media-amazon.com/images/I/81FChGNqztL._AC_UF894,1000_QL80_.jpg", isTrending: false, discountPercent: 10, originalPrice: 139, stars: 5, reviews: 2143},
  { id: 75, name: "Sony HT-S40R Barra de sonido 5.1", brand: "Sony", category: 7, image: "https://m.media-amazon.com/images/I/81e64lj1DjL.jpg", isTrending: true, discountPercent: 20, originalPrice: 279, stars: 5, reviews: 1120},
  { id: 76, name: "Samsung HW-Q700C Barra Dolby Atmos", brand: "Samsung", category: 7, image: "https://images-eu.ssl-images-amazon.com/images/I/51bLaii16uL._AC_UL495_SR435,495_.jpg", isTrending: true, discountPercent: 18, originalPrice: 499, stars: 5, reviews: 721},
  { id: 77, name: "LG XBOOM Go XG7", brand: "LG", category: 7, image: "https://m.media-amazon.com/images/I/81IjEGkkURL._AC_UF894,1000_QL80_.jpg", isTrending: false, discountPercent: 10, originalPrice: 179, stars: 4, reviews: 341},
  { id: 78, name: "Apple AirPods Pro (2ª gen USB-C)", brand: "Apple", category: 7, image: "https://thumb.pccomponentes.com/w-530-530/articles/1077/10777923/8467-airpods-pro-2a-generacion-con-estuche-de-carga-inalambrica-usb-c-blancos-00fd2382-552c-4126-ba97-00778893579b.jpg", isTrending: true, discountPercent: 5, originalPrice: 279, stars: 5, reviews: 1823},
  { id: 79, name: "Sony WF-C700N In-Ear", brand: "Sony", category: 7, image: "https://sony.scene7.com/is/image/sonyglobalsolutions/WF-C700N_Product-Intro_11_M?$productIntroPlatemobile$&fmt=png-alpha", isTrending: false, discountPercent: 12, originalPrice: 129, stars: 4, reviews: 512},
  { id: 80, name: "JBL Tune 520BT", brand: "JBL", category: 7, image: "https://cdn.milar.es/estaticos/extras/cache/fotos/productos/00/00/26/10/68/500X500_TUNE-520-BT-PURPURA-1-web.jpg", isTrending: false, discountPercent: 8, originalPrice: 59, stars: 4, reviews: 942},
  { id: 81, name: "Logitech Z407 Altavoces 2.1", brand: "Logitech", category: 7, image: "https://m.media-amazon.com/images/I/51s54H-J94L._AC_UF894,1000_QL80_.jpg", isTrending: false, discountPercent: 10, originalPrice: 109, stars: 4, reviews: 328},
  { id: 82, name: "Bose QuietComfort Ultra", brand: "Bose", category: 7, image: "https://m.media-amazon.com/images/I/51yWZxN3vRL.jpg", isTrending: true, discountPercent: 15, originalPrice: 429, stars: 5, reviews: 934},
  { id: 83, name: "Sony SRS-XE200", brand: "Sony", category: 7, image: "https://www.sony.es/image/b29cbd2015c20ae9002fa3f386efcbe1?fmt=pjpeg&resMode=bisharp&wid=360", isTrending: false, discountPercent: 7, originalPrice: 129, stars: 4, reviews: 221},
  { id: 84, name: "JBL Bar 2.1 Deep Bass", brand: "JBL", category: 7, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzhP_e9PANcX4-rcTAh000eB2hSmCWoG7kmg&s", isTrending: true, discountPercent: 10, originalPrice: 299, stars: 5, reviews: 623},

  // 8) HOGAR
  { id: 85, name: "Xiaomi Mi Robot Vacuum-Mop 2", brand: "Xiaomi", category: 8, image: "https://i01.appmifile.com/webfile/globalimg/pic/Mi-Robot-vacuum-Mop-2-ProB.png", isTrending: true, discountPercent: 15, originalPrice: 299, stars: 5, reviews: 882},
  { id: 86, name: "Cecotec Conga 9090 AI", brand: "Cecotec", category: 8, image: "https://m.media-amazon.com/images/I/61zgoZ3CqoL.jpg", isTrending: true, discountPercent: 20, originalPrice: 499, stars: 5, reviews: 1324},
  { id: 87, name: "Philips Airfryer XL", brand: "Philips", category: 8, image: "https://images.philips.com/is/image/philipsconsumer/vrs_6d11baec54e70687e83c56b332ae99ea637c0f7c?$pnglarge$&wid=960", isTrending: false, discountPercent: 10, originalPrice: 189, stars: 5, reviews: 654},
  { id: 88, name: "Cecotec Freidora de aire Cecofry Advance", brand: "Cecotec", category: 8, image: "https://media.cecotec.cloud/04986/cecofry-advance-9000-window_28sbx9_2.png", isTrending: false, discountPercent: 8, originalPrice: 149, stars: 4, reviews: 442},
  { id: 89, name: "Xiaomi Smart Air Purifier 4", brand: "Xiaomi", category: 8, image: "https://m.media-amazon.com/images/I/71jQqynFuVL.jpg", isTrending: false, discountPercent: 12, originalPrice: 199, stars: 4, reviews: 315},
  { id: 90, name: "Rowenta Silence Force Aspirador", brand: "Rowenta", category: 8, image: "https://thumb.pccomponentes.com/w-530-530/articles/51/514805/5601-rowenta-trineo-aspirador-seco-humedo-45-litros-400w-rojo-caracteristicas.jpg", isTrending: false, discountPercent: 7, originalPrice: 229, stars: 4, reviews: 218},
  { id: 91, name: "Tefal Express Steam Plancha", brand: "Tefal", category: 8, image: "https://dam.groupeseb.com/m/1d82f0b8231ad3ea/Digital-TF_FV2835E0_A.tif?timestamp=20250320033707", isTrending: false, discountPercent: 10, originalPrice: 59, stars: 4, reviews: 312},
  { id: 92, name: "Xiaomi Mi Smart Kettle", brand: "Xiaomi", category: 8, image: "https://m.media-amazon.com/images/I/61taJrJsmbL.jpg", isTrending: false, discountPercent: 5, originalPrice: 49, stars: 3, reviews: 198},
  { id: 93, name: "Orbegozo HBF 95 Estufa", brand: "Orbegozo", category: 8, image: "https://m.media-amazon.com/images/I/51bc2YTqHTL._AC_UF894,1000_QL80_.jpg", isTrending: false, discountPercent: 15, originalPrice: 139, stars: 4, reviews: 174},
  { id: 94, name: "Philips Humidificador Serie 2000", brand: "Philips", category: 8, image: "https://m.media-amazon.com/images/I/51vtaN++MpL._AC_UF894,1000_QL80_.jpg", isTrending: false, discountPercent: 8, originalPrice: 99, stars: 4, reviews: 147},
  { id: 95, name: "Xiaomi Mi Smart Microwave Oven", brand: "Xiaomi", category: 8, image: "https://www.powerplanetonline.com/cdnassets/microondas_xiaomi_03_ad_l.jpg", isTrending: true, discountPercent: 10, originalPrice: 179, stars: 4, reviews: 225},
  { id: 96, name: "Bosch MUM Serie 2 Robot de cocina", brand: "Bosch", category: 8, image: "https://m.media-amazon.com/images/I/61aUuvnYUBL.jpg", isTrending: true, discountPercent: 15, originalPrice: 229, stars: 5, reviews: 478},
];
